package Q4;
public interface Dice {
    public void roll(int times);
    public String toString();
}
